"""ШАГ 4. Переломы (changepoints) в потреблении МО: где детектировать, как честно сравнить детекторы.

Запуск:   python forecast/changepoints.py data outputs_changepoints [--surprises outputs_forecast/surprises_2024.csv]
Установка: pip install pandas pyarrow numpy ruptures matplotlib
Время:    ~2-4 минуты.

Почему не так, как в Sber.ipynb (подробно — forecast/REVIEW_Sber_v2.md):
  * Переломы искались в рядах «среднее по всем МО» из 24 точек. В таком ряду есть годовая сезонность
    (декабрьский пик) и +14% номинального роста. Детектор средней (l2) находит именно переход
    2023 -> 2024, то есть инфляцию, а не события. Это верно для каждой категории.
  * Искусственный шок вставлялся в середину ряда (n//2 = январь 2024), то есть туда, где этот
    «перелом из-за роста» уже есть. Recall=1.0 засчитывался за то, что было и без шока.
  * Порог у каждого метода свой, поэтому методы сравнивались при разной доле ложных тревог.

Что делаем здесь:
  0. Январь–март 2023 в 2–3 раза шумнее остальных месяцев, и у ~10% рядов стоят на другом уровне —
     это флаг качества данных (q1_2023_flag.csv); из поиска переломов эти месяцы исключены.
  1. Ряд = (МО, категория). Из log-потребления вычитаем медиану по всем МО этой категории в этом
     месяце. Уходят сезонность, общий рост и общие шоки, остаётся «отклонение МО от остальных».
     Перелом в нём — событие конкретного МО.
  2. Нормируем на робастный шум ряда (MAD первых разностей), тогда порог общий для всех рядов.
     Важно: отклонения МО устойчивы (автокорреляция ~0.6) — МО плавно «уезжают» от остальных,
     поэтому шумовой фон для детектора сильнее, чем кажется, и порог берём только из калибровки.
  3. Детекторы: PELT и BinSeg (офлайн, ruptures) и двусторонний CUSUM (онлайн, ловит в реальном времени).
  4. Бенчмарк: на 3000 реальных рядов вставляем ступеньку 5/10/20% в случайный месяц. Порог каждого
     детектора калибруется так, чтобы на тех же рядах БЕЗ вставки тревога была у ≤10% рядов.
     Тогда методы сравниваются честно: recall при одинаковой доле тревог.
  5. Применяем откалиброванный PELT ко всем рядам и сверяем с «сигналами отклонений» из шага 3.
"""
# %% импорты и настройки
import argparse
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import ruptures as rpt

try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
except NameError:                     # в Jupyter/Colab __file__ нет: forecast_v2.py должен лежать рядом или в forecast/
    sys.path[:0] = [str(Path.cwd()), str(Path.cwd() / "forecast")]
from forecast_v2 import TOTAL, load, make_meta, to_wide   # noqa: E402

CFG = dict(
    n_bench=3000,           # сколько рядов берём для бенчмарка
    sizes=(0.05, 0.10, 0.20),   # величина ступеньки (в логах ≈ 5%, 10%, 22%)
    skip_first=3,           # январь–март 2023 не используем для поиска переломов (см. q1_2023_flag)
    tau_range=(5, 16),      # месяц вставки (индекс после обрезки): с обеих сторон ≥5 точек
    tol=2,                  # перелом найден, если оценка ±2 мес. от истинного (офлайн)
    online_window=3,        # онлайн-тревога засчитывается, если пришла в [tau, tau+3]
    target_alarm=0.10,      # калибровка: тревога не более чем у 10% «чистых» рядов
    min_size=3,             # минимальная длина сегмента
    min_jump=0.05,          # на реальных данных показываем переломы ≥5%
    seed=7,
)


# %% подготовка рядов
def idiosyncratic(Y, cat):
    """log-потребление минус медиана категории в этом месяце: сезонность и общий рост уходят."""
    D = Y.copy()
    for c in np.unique(cat):
        s = cat == c
        D[s] -= np.median(Y[s], axis=0)
    return D


def month_scale(D, cat):
    """Типичное отклонение МО от собственного среднего в каждом месяце (робастно, по категории).
    Только для диагностики: показывает, что январь–март 2023 в 2–3 раза шумнее остальных месяцев.
    (Нормировка рядов на эту величину проверялась и снижала recall — поэтому не используется.)"""
    Dc = D - D.mean(axis=1, keepdims=True)          # отклонение ряда от собственного среднего
    S = np.ones_like(D)
    for c in np.unique(cat):
        s = cat == c
        S[s] = 1.4826 * np.median(np.abs(Dc[s]), axis=0)
    return S


def robust_sigma(D):
    d = np.diff(D, axis=1)
    return 1.4826 * np.median(np.abs(d - np.median(d, axis=1, keepdims=True)), axis=1) / np.sqrt(2) + 1e-6


# %% детекторы. Каждый возвращает список найденных индексов перелома (первый месяц нового уровня)
def pelt(z, pen, min_size):
    return rpt.Pelt(model="l2", min_size=min_size, jump=1).fit(z).predict(pen=pen)[:-1]   # [:-1] — конец ряда


def binseg(z, pen, min_size):
    return rpt.Binseg(model="l2", min_size=min_size, jump=1).fit(z).predict(pen=pen)[:-1]


def cusum_all(Z, h, k=0.5, warmup=6):
    """Двусторонний CUSUM по всем рядам сразу. База — среднее первых `warmup` месяцев.
    Возвращает месяц первой тревоги (или -1)."""
    mu = Z[:, :warmup].mean(axis=1)
    sp = np.zeros(len(Z))
    sn = np.zeros(len(Z))
    alarm = np.full(len(Z), -1)
    for t in range(warmup, Z.shape[1]):
        x = Z[:, t] - mu
        sp = np.maximum(0, sp + x - k)
        sn = np.maximum(0, sn - x - k)
        new = (alarm < 0) & ((sp > h) | (sn > h))
        alarm[new] = t
    return alarm


# %% калибровка и бенчмарк
def any_alarm_rate(Z, det, thr, min_size):
    return np.mean([len(det(z, thr, min_size)) > 0 for z in Z])


def calibrate_offline(Z, det, min_size, target, grid):
    for pen in grid:                         # от мягкого к строгому — первый, где тревог ≤ target
        r = any_alarm_rate(Z, det, pen, min_size)
        if r <= target:
            return pen, r
    return grid[-1], r


def calibrate_cusum(Z, target, grid):
    for h in grid:
        r = np.mean(cusum_all(Z, h) >= 0)
        if r <= target:
            return h, r
    return grid[-1], r


def inject(Z, mult, taus, size):
    """Ступенька размера `size` (в логах) с месяца tau, переведённая в z-единицы ряда."""
    Z2 = Z.copy()
    for i, t in enumerate(taus):
        Z2[i, t:] += size * mult[i, t:]
    return Z2


def standardize(D, S):
    """Делим на разброс месяца, затем на шум ряда. Возвращает Z и множитель «лог-единица -> z» по месяцам."""
    U = D / S
    sig = robust_sigma(U)
    Z = (U - U.mean(axis=1, keepdims=True)) / sig[:, None]
    return Z, 1.0 / (S * sig[:, None])


def q1_2023_flag(D, meta, thr=0.10):
    """МО, у которых уровень относительно остальных в янв–мар 2023 отличается от апр–дек 2023 больше чем на thr.
    Скорее всего это особенность оценок в начале ряда, а не событие. Проверять до любых выводов о 2023 годе."""
    d = D[:, :3].mean(axis=1) - D[:, 3:12].mean(axis=1)
    df = meta[["territory_id", "category"]].copy()
    df["q1_vs_rest_2023_pct"] = np.round(100 * (np.exp(d) - 1), 1)
    return df[np.abs(d) > np.log1p(thr)]


def benchmark(D, S, cfg=CFG):
    rng = np.random.default_rng(cfg["seed"])
    idx = rng.choice(len(D), min(cfg["n_bench"], len(D)), replace=False)
    Z, mult = standardize(D[idx], S[idx])
    taus = rng.integers(*cfg["tau_range"], size=len(idx))
    ms = cfg["min_size"]

    grid = np.round(np.geomspace(2, 400, 40), 2)
    calib = {
        "PELT": calibrate_offline(Z[:1000], pelt, ms, cfg["target_alarm"], grid),
        "BinSeg": calibrate_offline(Z[:1000], binseg, ms, cfg["target_alarm"], grid),
        "CUSUM": calibrate_cusum(Z, cfg["target_alarm"], np.round(np.geomspace(1, 200, 60), 2)),
    }
    print("Калибровка порога на рядах без вставки (цель: тревога у ≤{:.0%} рядов):".format(cfg["target_alarm"]))
    for m, (thr, r) in calib.items():
        print(f"  {m:<7} порог={thr:<8} доля рядов с тревогой={r:.3f}")

    rows = []
    for size in cfg["sizes"]:
        Z2 = inject(Z, mult, taus, size)
        for m in ("PELT", "BinSeg"):
            det = pelt if m == "PELT" else binseg
            thr = calib[m][0]
            hit, extra, err = [], [], []
            for z, t in zip(Z2, taus):
                bk = det(z, thr, ms)
                near = [b for b in bk if abs(b - t) <= cfg["tol"]]
                hit.append(bool(near))
                extra.append(len(bk) - (1 if near else 0))
                if near:
                    err.append(min(abs(b - t) for b in near))
            rows.append(dict(method=m, type="офлайн", shock=f"{size:.0%}", recall=np.mean(hit),
                             extra_per_series=np.mean(extra), loc_error_months=np.mean(err) if err else np.nan,
                             delay_months=np.nan))
        a = cusum_all(Z2, calib["CUSUM"][0])
        ok = (a >= taus) & (a <= taus + cfg["online_window"])
        early = (a >= 0) & (a < taus)
        rows.append(dict(method="CUSUM", type="онлайн", shock=f"{size:.0%}", recall=ok.mean(),
                         extra_per_series=early.mean(), loc_error_months=np.nan,
                         delay_months=(a[ok] - taus[ok]).mean() if ok.any() else np.nan))
    return pd.DataFrame(rows), calib


# %% применение к реальным рядам
def real_breaks(D, S, meta, dates, pen, cfg=CFG):
    Z, _ = standardize(D, S)
    out = []
    for i, z in enumerate(Z):
        bk = pelt(z, pen, cfg["min_size"])
        edges = [0] + bk + [len(z)]
        for j, b in enumerate(bk):
            before = D[i, edges[j]:b].mean()
            after = D[i, b:edges[j + 2]].mean()
            jump = np.exp(after - before) - 1
            if abs(jump) >= cfg["min_jump"]:
                out.append(dict(territory_id=meta["territory_id"].iat[i], category=meta["category"].iat[i],
                                break_month=dates[b].strftime("%Y-%m"), jump_vs_peers_pct=round(100 * jump, 1)))
    return pd.DataFrame(out)


# %% основной сценарий
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data", nargs="?", default="data")
    ap.add_argument("out", nargs="?", default="outputs_changepoints")
    ap.add_argument("--surprises", default="outputs_forecast/surprises_2024.csv")
    in_notebook = "ipykernel" in sys.argv[0] or "colab" in sys.argv[0]
    args = ap.parse_args([] if in_notebook else None)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    cons, ma = load(args.data)
    w = to_wide(cons)
    dates = pd.DatetimeIndex(w.columns)
    Y = np.log(w.values.astype(float))
    meta = make_meta(w, ma)
    cat = meta["cat"].values

    # 0) что находит схема Sber.ipynb: ряд «среднее по МО» каждой категории
    print("\n== Схема Sber.ipynb: PELT (l2, pen=3·log n·std²) на среднем по МО ряду категории")
    raw = w.groupby(level="category").mean()
    for c, y in raw.iterrows():
        y = y.values
        bk = rpt.Pelt(model="l2", min_size=2, jump=1).fit(y).predict(pen=3 * np.log(len(y)) * np.std(y) ** 2)
        print(f"  {c:<22} predict() = {bk}  -> реальных переломов {len(bk) - 1}: "
              f"{[dates[b].strftime('%Y-%m') for b in bk[:-1]]}")
    print("  Последний элемент predict() — конец ряда (24), не перелом. Найденное — переход 2023->2024 (рост цен).")

    # 1) бенчмарк на МО-рядах с вычетом общего фона
    D_full = idiosyncratic(Y, cat)
    S_full = month_scale(D_full, cat)
    print("\n== Качество данных: типичное отклонение МО от своего среднего по месяцам («Все категории», %):")
    print(dict(zip(dates.strftime("%Y-%m"), np.round(100 * S_full[meta["category"].values == TOTAL][0], 1).tolist())))
    q1 = q1_2023_flag(D_full, meta)
    q1.to_csv(out / "q1_2023_flag.csv", index=False)
    print(f"Ряды, где янв–мар 2023 на другом уровне (>10%) относительно остальных МО: {len(q1)} из {len(D_full)} "
          f"(«Все категории»: {(q1['category'] == TOTAL).sum()} МО). Эти месяцы исключены из поиска переломов.")
    k = CFG["skip_first"]
    D, dates = D_full[:, k:], dates[k:]
    S = np.ones_like(D)
    print(f"\n== Бенчмарк детекторов: {CFG['n_bench']} рядов МО×категория, ступенька в случайный месяц")
    bench, calib = benchmark(D, S)
    print(bench.round(3).to_string(index=False))
    bench.to_csv(out / "detector_benchmark.csv", index=False)

    # 2) реальные переломы
    pen = calib["PELT"][0]
    br = real_breaks(D, S, meta, dates, pen)
    br.to_csv(out / "breaks_real.csv", index=False)
    n_ser = len(D)
    print(f"\n== Реальные переломы (PELT, порог из калибровки, |скачок| ≥ {CFG['min_jump']:.0%}): "
          f"{len(br)} переломов в {br.groupby(['territory_id', 'category']).ngroups} рядах из {n_ser}")
    print("Доля рядов с переломом по категориям, %:")
    share = 100 * br.drop_duplicates(["territory_id", "category"]).groupby("category").size() / (n_ser / 6)
    print(share.round(1).to_string())
    print("Распределение месяцев переломов («Все категории»):")
    print(br[br["category"] == TOTAL]["break_month"].value_counts().sort_index().to_string())
    print("ВНИМАНИЕ: порог калибровался на этих же рядах (цель ≤10% рядов с тревогой), поэтому общая доля ~10% —\n"
          "следствие калибровки, а не доказательство событий. Смысл имеют ранжирование по величине скачка,\n"
          "различия между категориями и совпадение с независимым методом (ниже).")

    # 3) сверка с сигналами отклонений из шага 3
    sp_f = Path(args.surprises)
    if sp_f.exists():
        sp = pd.read_csv(sp_f, dtype={"territory_id": str})
        # сигналы есть только за 2024 год, поэтому сравниваем с переломами 2024 года (любая категория)
        br24 = br[br["break_month"] >= "2024-02"]
        a = set(zip(br24["territory_id"], br24["category"]))
        b = set(zip(sp["territory_id"], sp["category"]))
        expected = len(a) * len(b) / n_ser
        print(f"\n== 2024 год: рядов с переломом {len(a)}, рядов с сигналом отклонения {len(b)}, в обоих списках {len(a & b)} "
              f"(при независимости ожидалось бы {expected:.0f}, превышение в {len(a & b) / expected:.1f} раза)")
        key = br24["territory_id"] + "|" + br24["category"]
        both = br24[key.isin({f"{t}|{c}" for t, c in a & b})]
        both.to_csv(out / "breaks_confirmed_by_surprises.csv", index=False)
        print("Пересечение двух независимых методов — самый надёжный список МО для разбора (breaks_confirmed_by_surprises.csv)")

    # картинки
    fig, ax = plt.subplots(figsize=(6.5, 4))
    for m in bench["method"].unique():
        b = bench[bench["method"] == m]
        ax.plot(b["shock"], b["recall"], marker="o", label=m)
    ax.axhline(CFG["target_alarm"], ls="--", c="gray", lw=1)
    ax.text(0, CFG["target_alarm"] + 0.02, "доля тревог без шока", fontsize=8, color="gray")
    ax.set_ylim(0, 1); ax.set_xlabel("величина вставленной ступеньки"); ax.set_ylabel("recall")
    ax.set_title("Детекторы при одинаковой доле ложных тревог (10%)"); ax.grid(alpha=.3); ax.legend()
    fig.tight_layout(); fig.savefig(out / "detector_recall.png", dpi=150); plt.close(fig)

    t = br[br["category"] == TOTAL].copy()
    ex = t.reindex(t["jump_vs_peers_pct"].abs().sort_values(ascending=False).index).head(4)
    if len(ex):
        fig, axes = plt.subplots(1, len(ex), figsize=(3.6 * len(ex), 3), sharey=False)
        axes = np.atleast_1d(axes)
        for ax, (_, r) in zip(axes, ex.iterrows()):
            i = np.where((meta["territory_id"] == r["territory_id"]).values & (meta["category"] == TOTAL).values)[0][0]
            ax.plot(dates, 100 * (np.exp(D[i]) - 1), marker=".")
            ax.axvline(pd.Timestamp(r["break_month"]), c="red", ls="--")
            ax.set_title(f"МО {r['territory_id']}: {r['jump_vs_peers_pct']:+.0f}%", fontsize=9)
            ax.tick_params(axis="x", labelrotation=45, labelsize=7)
        axes[0].set_ylabel("отклонение от медианы МО, %")
        fig.suptitle("Примеры переломов («Все категории», без сезонности и общего роста)", fontsize=10)
        fig.tight_layout(); fig.savefig(out / "break_examples.png", dpi=150); plt.close(fig)
    print(f"\nГотово: {out.resolve()}")


if __name__ == "__main__":
    main()
