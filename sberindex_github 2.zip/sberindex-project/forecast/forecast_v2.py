"""ШАГ 3. Прогноз потребления МО: честная проверка + сезонная модель с ростом + глобальный LightGBM.

Запуск:   python forecast/forecast_v2.py data outputs_forecast [--types outputs/types_2023.csv]
Установка: pip install pandas pyarrow numpy lightgbm matplotlib
Время:    ~3-6 минут на ноутбуке (11 обучений LightGBM).

Что исправлено относительно ноутбука команды (подробно — forecast/EXPLANATION.md):
  1. Одна точка прогноза (декабрь 2023) -> скользящее начало прогноза (rolling origin):
     11 точек для h=1, 9 для h=3, 6 для h=6. Выводы по одной точке — шум.
  2. MAE в рублях, смешанный по категориям, и R² по уровням (~0.99 у всех) -> WAPE по каждой
     категории отдельно, смещение (bias) и доля точек, где модель лучше эталона.
  3. Не учитывался рост цен и доходов (+14% г/г). Добавлен эталон «сезонная наивная × годовой рост»
     с оценкой роста по МО, по категории и их смесью (shrinkage).
  4. Рекурсивный LightGBM на уровнях с territory_id (2000 категорий -> переобучение) ->
     прямой (direct) глобальный LightGBM, предсказывающий годовой рост целевого месяца в логах.
  5. Prophet на 12 точках убран: годовую сезонность по одному году он оценить не может.
  6. Добавлено: интервалы прогноза с проверкой покрытия, «сигналы отклонений» по МО,
     качество по доступности рынков и по типам МО из шага 2, прогноз на 2025 год.

Файл размечен ячейками `# %%` — открывается как ноутбук в VS Code / Jupyter (jupytext).
"""
# %% импорты и настройки
import argparse
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import lightgbm as lgb
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

CFG = dict(
    growth_window=3,       # сколько последних месяцев годового роста усредняем
    shrink=0.5,            # вес собственного роста МО против медианы категории
    first_origin=12,       # с декабря 2023 (T=11) рост ещё не наблюдаем, поэтому основные точки — с января 2024
    select_origins=range(12, 17),   # на этих точках выбираем модель…
    holdout_origins=range(17, 23),  # …а на этих честно проверяем выбранную
    interval=0.8,          # уровень интервала прогноза
    z_flag=4.0,            # порог «сигнала отклонения» в робастных стандартных отклонениях
    max_train_rows=600_000,
    seed=42,
    report_h=(1, 3, 6, 12),  # горизонты из задания
    prophet_n=600,         # Prophet обучается на каждом ряду отдельно — берём выборку рядов (100 на категорию)
    prophet_jobs=-1,       # параллельно на всех ядрах
    chronos_model="amazon/chronos-bolt-small",   # фундаментальная модель (zero-shot, без дообучения)
)
LGB_PARAMS = dict(objective="l1", n_estimators=500, learning_rate=0.05, num_leaves=63,
                  min_child_samples=200, subsample=0.8, subsample_freq=1, colsample_bytree=0.8,
                  reg_lambda=1.0, random_state=42, n_jobs=-1, verbose=-1)
TOTAL = "Все категории"
MODELS = ["Naive", "SNaive", "Mean12", "SNaive+g_MO", "SNaive+g_cat", "SNaive+g_shrunk", "LGBM_direct", "Hybrid",
          "Ensemble"]
FINAL_CANDIDATES = ["SNaive+g_MO", "SNaive+g_shrunk", "LGBM_direct", "Hybrid", "Ensemble"]
# Ensemble = среднее (в логах) прогнозов SNaive+g_shrunk и LGBM_direct: комбинация прогнозов обычно
# устойчивее любой отдельной модели (Bates & Granger, 1969; итоги соревнований M4/M5)
HYBRID_MAX_H = 3   # Hybrid = LightGBM на h<=3, SNaive+g_shrunk дальше (LightGBM мало учится на длинных горизонтах)
FEATS = ["h", "cat", "log_ma", "g1", "gk", "g_cat", "g_total", "mom1", "mom3",
         "rel_level", "sn_gap", "season_step", "season_step_cat"]


# %% данные
def load(data_dir):
    d = Path(data_dir)
    cons = pd.read_parquet(d / "consumption.parquet")
    val = "consumption" if "consumption" in cons.columns else "value"   # в выгрузке столбец называется value
    cons = cons.rename(columns={val: "y"})
    cons["date"] = pd.to_datetime(cons["date"])
    cons["territory_id"] = cons["territory_id"].astype(str)
    f = d / "market_access.parquet"
    ma = pd.read_parquet(f) if f.exists() else pd.DataFrame({"territory_id": [], "market_access": []})
    ma["territory_id"] = ma["territory_id"].astype(str)
    return cons, ma


def to_wide(cons):
    """Ряд = (МО, категория), столбцы = месяцы. Оставляем МО, у которых ВСЕ 6 категорий полные и > 0,
    чтобы все модели и категории сравнивались на одном наборе МО."""
    w = cons.pivot_table(index=["territory_id", "category"], columns="date", values="y")
    full = (w.notna() & (w > 0)).all(axis=1)
    ok = full.groupby(level="territory_id").all()
    ok = ok[ok].index
    n_cat = w.index.get_level_values("category").nunique()
    ok = [t for t in ok if (w.loc[t].shape[0] == n_cat)]
    w = w.loc[w.index.get_level_values("territory_id").isin(ok)]
    n_all = cons["territory_id"].nunique()
    print(f"МО с полными рядами по всем категориям: {len(ok)} из {n_all} "
          f"(остальные {n_all - len(ok)} — с пропусками; прогноз для них нужен отдельный, см. EXPLANATION.md)")
    return w


def make_meta(w, ma):
    meta = w.index.to_frame(index=False)
    s = ma.drop_duplicates("territory_id").set_index("territory_id")["market_access"]
    lma = np.log1p(s.reindex(meta["territory_id"]).values)
    meta["log_ma"] = np.where(np.isnan(lma), np.nanmin(lma) if np.isfinite(lma).any() else 0, lma)  # изолированные МО
    meta["cat"] = pd.Categorical(meta["category"]).codes
    tot_pos = meta.reset_index().query("category == @TOTAL").set_index("territory_id")["index"]
    meta["tot_idx"] = tot_pos.reindex(meta["territory_id"]).values
    return meta


# %% эталонные (сезонные) модели — всё в логарифмах
def cat_median(v, cat):
    return pd.Series(v).groupby(cat).transform("median").values


def yoy_growth(Y, T, k):
    """Средний годовой рост (в логах) за последние k месяцев до T включительно; NaN, если года истории нет."""
    k = min(k, T - 11)
    if k <= 0:
        return np.full(len(Y), np.nan)
    return (Y[:, T - k + 1:T + 1] - Y[:, T - k - 11:T - 11]).mean(axis=1)


def baselines(Y, T, h, cat, cfg=CFG):
    sn = Y[:, T + h - 12]                              # тот же месяц год назад
    g = yoy_growth(Y, T, cfg["growth_window"])
    g_mo = np.nan_to_num(g, nan=0.0)
    g_cat = np.nan_to_num(cat_median(g, cat), nan=0.0)
    w = cfg["shrink"]
    return {
        "Naive": Y[:, T],
        "SNaive": sn,
        "Mean12": np.log(np.exp(Y[:, T - 11:T + 1]).mean(axis=1)),
        "SNaive+g_MO": sn + g_mo,
        "SNaive+g_cat": sn + g_cat,
        "SNaive+g_shrunk": sn + w * g_mo + (1 - w) * g_cat,
    }


# %% признаки для глобального LightGBM (прямой прогноз годового роста целевого месяца)
def features(Y, T, h, meta):
    nan = np.full(len(Y), np.nan)
    cat = meta["cat"].values
    gk = yoy_growth(Y, T, 3)
    g1 = Y[:, T] - Y[:, T - 12] if T >= 12 else nan
    step = Y[:, T + h - 12] - Y[:, T - 12] if T >= 12 else nan   # сезонный шаг «месяц T -> месяц T+h» год назад
    F = np.column_stack([
        np.full(len(Y), h),
        cat,
        meta["log_ma"].values,
        g1,
        gk,
        cat_median(gk, cat),                      # общий рост категории (по всем МО)
        gk[meta["tot_idx"].values],               # рост «Все категории» этого же МО
        Y[:, T] - Y[:, T - 1],
        Y[:, T] - Y[:, T - 3],
        Y[:, T] - cat_median(Y[:, T], cat),       # уровень МО относительно медианы категории
        Y[:, T + h - 12] - Y[:, T],               # разрыв «сезонная наивная − последнее значение»
        step,
        cat_median(step, cat),                    # тот же шаг, усреднённый по всем МО (сезонность «из толпы»)
    ]).astype(np.float32)
    target = Y[:, T + h] - Y[:, T + h - 12] if T + h < Y.shape[1] else None
    return F, target


def build_blocks(Y, meta):
    """Все пары (T, h), из которых можно учить модель: T>=3, T+h>=12, T+h<=последний месяц."""
    n_t = Y.shape[1]
    blocks = {}
    for T in range(3, n_t - 1):
        for h in range(1, 13):
            if 12 <= T + h <= n_t - 1:
                blocks[(T, h)] = features(Y, T, h, meta)
    return blocks


def train_lgbm(blocks, T0, cfg=CFG, params=LGB_PARAMS):
    """Учим только на парах, у которых целевой месяц T+h <= T0 (никакой утечки из будущего)."""
    keys = [k for k in blocks if k[0] + k[1] <= T0]
    if not keys:
        return None
    X = np.vstack([blocks[k][0] for k in keys])
    y = np.concatenate([blocks[k][1] for k in keys])
    if len(y) > cfg["max_train_rows"]:
        idx = np.random.default_rng(cfg["seed"]).choice(len(y), cfg["max_train_rows"], replace=False)
        X, y = X[idx], y[idx]
    m = lgb.LGBMRegressor(**params)
    m.fit(pd.DataFrame(X, columns=FEATS), y, categorical_feature=["cat"])
    return m


# %% прогон по скользящему началу прогноза
def run_backtest(Y, meta, blocks, origins, cfg=CFG):
    """P[(T0, h)] = матрица (ряды x модели) прогнозов в логах; T0 — последний известный месяц."""
    n_t = Y.shape[1]
    cat = meta["cat"].values
    P, trained = {}, {}
    for T0 in origins:
        t0 = time.time()
        model = train_lgbm(blocks, T0, cfg)
        trained[T0] = model is not None
        for h in range(1, 13):
            if T0 + h > n_t - 1:
                break
            b = baselines(Y, T0, h, cat, cfg)
            if model is not None:
                F, _ = features(Y, T0, h, meta)
                b["LGBM_direct"] = Y[:, T0 + h - 12] + model.predict(pd.DataFrame(F, columns=FEATS))
            else:                       # данных для обучения ещё нет — честно отдаём эталон
                b["LGBM_direct"] = b["SNaive+g_shrunk"]
            b["Hybrid"] = b["LGBM_direct"] if h <= HYBRID_MAX_H else b["SNaive+g_shrunk"]
            b["Ensemble"] = 0.5 * (b["LGBM_direct"] + b["SNaive+g_shrunk"])
            P[(T0, h)] = np.column_stack([b[m] for m in MODELS]).astype(np.float64)
        print(f"  точка прогноза T0={T0:>2}: LightGBM {'обучен' if model else 'нет данных -> эталон'} "
              f"({time.time() - t0:.0f} c)")
    return P, trained


# %% метрики
def error_table(P, Y, meta, dates, keys):
    """Длинная таблица сумм ошибок по (точка, горизонт, модель, категория) — в рублях."""
    rows = []
    cats = meta["category"].values
    for (T0, h) in keys:
        y = np.exp(Y[:, T0 + h])
        pred = np.exp(P[(T0, h)])
        for j, m in enumerate(MODELS):
            e = pred[:, j] - y
            df = pd.DataFrame({"category": cats, "ae": np.abs(e), "e": e, "y": y, "se": e ** 2})
            df["dev2"] = (y - df.groupby("category")["y"].transform("mean")) ** 2
            g = df.groupby("category").sum()
            for c, r in g.iterrows():
                rows.append(dict(origin=dates[T0].strftime("%Y-%m"), T0=T0, h=h, model=m, category=c,
                                 abs_err=r["ae"], err=r["e"], y=r["y"], sse=r["se"], sst=r["dev2"],
                                 n=int((cats == c).sum())))
    return pd.DataFrame(rows)


def headline_table(err, cfg=CFG):
    """MAE (руб.) и R² по горизонтам задания 1/3/6/12, по категориям.
    h=1,3,6 — среднее по всем точкам прогноза 2024 года; h=12 — единственная возможная точка (дек-2023 -> дек-2024).
    MAE = Σ|прогноз − факт| / число МО·точек; R² = 1 − ΣSSE / ΣSST, SST — разброс факта между МО в том же месяце."""
    e = err.copy()
    keep = ((e["h"].isin([h for h in cfg["report_h"] if h < 12]) & (e["T0"] >= cfg["first_origin"]))
            | ((e["h"] == 12) & (e["T0"] == 11)))
    e = e[keep]
    g = e.groupby(["category", "h", "model"])[["abs_err", "sse", "sst", "n"]].sum()
    g["MAE"] = g["abs_err"] / g["n"]
    g["R2"] = 1 - g["sse"] / g["sst"]
    g["origins"] = e.groupby(["category", "h", "model"])["T0"].nunique()
    return g[["MAE", "R2", "origins"]].reset_index()


def summarize(err, hs):
    e = err[err["h"].isin(hs)]
    g = e.groupby(["h", "model", "category"])[["abs_err", "err", "y"]].sum()
    g["WAPE_%"] = 100 * g["abs_err"] / g["y"]
    g["bias_%"] = 100 * g["err"] / g["y"]
    g["origins"] = e.groupby(["h", "model", "category"])["T0"].nunique()
    sub = g.reset_index()
    sub5 = sub[sub["category"] != TOTAL]
    macro = sub5.groupby(["h", "model"])["WAPE_%"].mean().unstack("model")[MODELS]
    total = sub[sub["category"] == TOTAL].set_index(["h", "model"])["WAPE_%"].unstack("model")[MODELS]
    return sub, macro, total


def wins_vs(err, ref, hs):
    """В скольких точках прогноза модель лучше эталона ref по macro-WAPE (5 категорий)."""
    e = err[(err["category"] != TOTAL) & err["h"].isin(hs)].copy()
    e["wape"] = e["abs_err"] / e["y"]
    w = e.groupby(["h", "T0", "model"])["wape"].mean().unstack("model")
    out = {}
    for h in hs:
        x = w.loc[h]
        out[h] = {m: f"{int((x[m] < x[ref]).sum())}/{len(x)}" for m in MODELS if m != ref}
    return pd.DataFrame(out).T


def bootstrap_diff(P, Y, meta, keys, m_a, m_b, B=500, seed=0):
    """95% ДИ разницы macro-WAPE (m_a − m_b, п.п.) — бутстрэп по МО (ряды одного МО идут вместе).
    Общие для всех МО шоки месяца этим не учитываются — поэтому смотрим ещё и на победы по точкам."""
    ia, ib = MODELS.index(m_a), MODELS.index(m_b)
    terr = meta["territory_id"].values
    cats = meta["category"].values
    mo_codes, mo = np.unique(terr, return_inverse=True)
    sub_cats = [c for c in np.unique(cats) if c != TOTAL]
    A = {c: np.zeros(len(mo_codes)) for c in sub_cats}
    Bm = {c: np.zeros(len(mo_codes)) for c in sub_cats}
    Ysum = {c: np.zeros(len(mo_codes)) for c in sub_cats}
    for (T0, h) in keys:
        y = np.exp(Y[:, T0 + h])
        ea = np.abs(np.exp(P[(T0, h)][:, ia]) - y)
        eb = np.abs(np.exp(P[(T0, h)][:, ib]) - y)
        for c in sub_cats:
            s = cats == c
            np.add.at(A[c], mo[s], ea[s]); np.add.at(Bm[c], mo[s], eb[s]); np.add.at(Ysum[c], mo[s], y[s])
    W = np.random.default_rng(seed).multinomial(len(mo_codes), np.ones(len(mo_codes)) / len(mo_codes), size=B)
    d = np.mean([(W @ A[c] - W @ Bm[c]) / (W @ Ysum[c]) for c in sub_cats], axis=0) * 100
    point = np.mean([(A[c].sum() - Bm[c].sum()) / Ysum[c].sum() for c in sub_cats]) * 100
    return point, np.percentile(d, 2.5), np.percentile(d, 97.5)


# %% интервалы прогноза (эмпирические, как split-conformal: симметричный квантиль |ошибки| в логах)
# Симметричный — чтобы смещение 1-2 прошлых точек не сдвигало интервал целиком выше/ниже прогноза.
def log_errors(P, Y, j, T0, h):
    return Y[:, T0 + h] - P[(T0, h)][:, j]


def calib_errors(P, Y, meta, j, h, before, cfg=CFG):
    """Ошибки модели j на горизонте h из точек, чей целевой месяц уже наступил к моменту `before`."""
    ks = [(T, hh) for (T, hh) in P if hh == h and T >= cfg["first_origin"] and T + hh <= before]
    if not ks:
        return None, 0
    E = np.concatenate([log_errors(P, Y, j, T, h) for (T, _) in ks])
    C = np.concatenate([meta["cat"].values] * len(ks))
    return (E, C), len(ks)


def coverage_table(P, Y, meta, j, cfg=CFG):
    """Покрытие интервала двумя способами:
    full — факт попал в интервал (общий шок месяца + отклонение МО);
    peer — после вычета общего для категории шока месяца (медианы ошибок по всем МО).
    Если peer ~ номинал, а full ниже — интервал портит именно общий шок, а не модель МО."""
    rows = []
    cat = meta["cat"].values

    def deshock(E, C, n_blocks):
        out = E.copy()
        for b in np.array_split(np.arange(len(E)), n_blocks):
            for c in np.unique(C[b]):
                s = b[C[b] == c]
                out[s] -= np.median(E[s])
        return out

    for (T0, h) in sorted(P):
        if T0 < cfg["first_origin"]:
            continue
        cal, n_or = calib_errors(P, Y, meta, j, h, before=T0, cfg=cfg)
        if cal is None:
            continue
        E, C = cal
        Ed = deshock(E, C, n_or)
        e = log_errors(P, Y, j, T0, h)
        ed = deshock(e, cat, 1)
        full, peer = np.zeros(len(e), bool), np.zeros(len(e), bool)
        for c in np.unique(cat):
            s = cat == c
            q = np.quantile(np.abs(E[C == c]), cfg["interval"])
            full[s] = np.abs(e[s]) <= q
            q = np.quantile(np.abs(Ed[C == c]), cfg["interval"])
            peer[s] = np.abs(ed[s]) <= q
        shock = pd.Series(e).groupby(cat).transform("median").values
        rows.append(dict(T0=T0, h=h, calib_origins=n_or, coverage_full=full.mean(), coverage_peer=peer.mean(),
                         shock_share_of_var=np.var(shock) / np.var(e)))
    return pd.DataFrame(rows)


def surprises(P, Y, meta, dates, j, cfg=CFG):
    """Сигнал отклонения: факт месяца отличается от прогноза на 1 месяц СИЛЬНЕЕ, ЧЕМ У ДРУГИХ МО
    в этой же категории и в этом же месяце (общий шок месяца вычитается).
    z = (ошибка − медиана ошибок категории) / (1.4826·MAD). Это список «что-то случилось в МО»."""
    out = []
    cat = meta["cat"].values
    for T0 in sorted({k[0] for k in P}):
        if T0 < cfg["first_origin"] or (T0, 1) not in P:
            continue
        e = log_errors(P, Y, j, T0, 1)
        z = np.full(len(e), np.nan)
        for c in np.unique(cat):
            s = cat == c
            med = np.median(e[s])
            z[s] = (e[s] - med) / (1.4826 * np.median(np.abs(e[s] - med)) + 1e-9)
        df = meta[["territory_id", "category"]].copy()
        df["month"] = dates[T0 + 1].strftime("%Y-%m")
        df["fact"] = np.exp(Y[:, T0 + 1]).round(0)
        df["forecast"] = np.exp(P[(T0, 1)][:, j]).round(0)
        df["deviation_%"] = (100 * (np.exp(e) - 1)).round(1)
        df["z"] = z.round(2)
        out.append(df[np.abs(z) > cfg["z_flag"]])
    return pd.concat(out, ignore_index=True) if out else pd.DataFrame()


# %% Prophet — базовая модель из задания. Обучается на каждом ряду отдельно (как и положено Prophet)
def prophet_backtest(Y, dates, idx, origins, n_jobs=-1):
    """Для каждого ряда из idx и каждой точки T0: обучить Prophet на месяцах <= T0, прогноз на 1..12 мес.
    Настройки: линейный тренд, годовая сезонность (3 гармоники), без недельной/дневной.
    При 12–23 месячных точках годовая сезонность Prophet плохо определена — это свойство данных, а не настройки."""
    from joblib import Parallel, delayed

    n_t = Y.shape[1]

    def one(i):
        import logging
        import warnings
        warnings.filterwarnings("ignore")
        for name in ("prophet", "cmdstanpy"):
            logging.getLogger(name).setLevel(logging.ERROR)
        from prophet import Prophet
        for name in ("prophet", "cmdstanpy"):
            logging.getLogger(name).setLevel(logging.ERROR)
            logging.getLogger(name).disabled = True
        y = np.exp(Y[i])
        out = {}
        for T0 in origins:
            H = min(12, n_t - 1 - T0)
            m = Prophet(growth="linear", yearly_seasonality=3, weekly_seasonality=False,
                        daily_seasonality=False, uncertainty_samples=0)
            m.fit(pd.DataFrame({"ds": dates[:T0 + 1], "y": y[:T0 + 1]}))
            yhat = m.predict(pd.DataFrame({"ds": dates[T0 + 1:T0 + 1 + H]}))["yhat"].values
            out[T0] = np.log(np.clip(yhat, 1.0, None))
        return out

    res = Parallel(n_jobs=n_jobs)(delayed(one)(i) for i in idx)
    PP = {}
    for T0 in origins:
        for h in range(1, min(12, n_t - 1 - T0) + 1):
            PP[(T0, h)] = np.array([r[T0][h - 1] for r in res])
    return PP


def prophet_sample(meta, n, seed):
    """Стратифицированная выборка рядов: поровну на каждую категорию."""
    rng = np.random.default_rng(seed)
    per = n // meta["category"].nunique()
    return np.sort(np.concatenate([rng.choice(np.where(meta["category"].values == c)[0], per, replace=False)
                                   for c in meta["category"].unique()]))


def chronos_backtest(Y, idx, origins, model_name):
    """Chronos-Bolt (Amazon, 2024) — предобученная на ~100 тыс. рядов трансформерная модель, прогноз без
    дообучения (zero-shot). Для каждой точки T0 модель получает историю ряда до T0 и выдаёт медиану прогноза
    на 1..12 мес. Возвращает dict[(T0, h)] -> log-прогноз, или (None, причина), если модель недоступна
    (веса скачиваются с huggingface.co)."""
    try:
        import torch
        from chronos import BaseChronosPipeline
        pipe = BaseChronosPipeline.from_pretrained(model_name, device_map="cpu", torch_dtype=torch.float32)
    except Exception as e:                       # нет пакета или нет доступа к весам — честно пропускаем
        return None, f"{type(e).__name__}: {str(e)[:160]}"
    n_t = Y.shape[1]
    PC = {}
    for T0 in origins:
        H = min(12, n_t - 1 - T0)
        ctx = torch.tensor(np.exp(Y[idx, :T0 + 1]), dtype=torch.float32)
        q, mean = pipe.predict_quantiles(ctx, prediction_length=H, quantile_levels=[0.5])
        med = q[:, :, 0].numpy()
        for h in range(1, H + 1):
            PC[(T0, h)] = np.log(np.clip(med[:, h - 1], 1.0, None))
    return PC, "ok"


def compare_with_prophet(P, PP, Y, idx, cfg=CFG, extra=None):
    """MAE и R² всех моделей и Prophet на одной и той же выборке рядов и тех же точках прогноза.
    extra: {имя: dict[(T0, h)] -> log-прогноз по рядам idx} — например, Chronos."""
    rows = []
    for (T0, h), pp in PP.items():
        ok = (h in cfg["report_h"]) and ((h < 12 and T0 >= cfg["first_origin"]) or (h == 12 and T0 == 11))
        if not ok:
            continue
        y = np.exp(Y[idx, T0 + h])
        preds = {m: np.exp(P[(T0, h)][idx, j]) for j, m in enumerate(MODELS)}
        preds["Prophet"] = np.exp(pp)
        for name, PX in (extra or {}).items():
            preds[name] = np.exp(PX[(T0, h)])
        for m, p in preds.items():
            rows.append(dict(T0=T0, h=h, model=m, abs_err=np.abs(p - y).sum(), sse=((p - y) ** 2).sum(),
                             sst=((y - y.mean()) ** 2).sum(), n=len(y), wape=np.abs(p - y).sum() / y.sum()))
    d = pd.DataFrame(rows)
    g = d.groupby(["h", "model"])[["abs_err", "sse", "sst", "n"]].sum()
    g["MAE"] = g["abs_err"] / g["n"]
    g["R2"] = 1 - g["sse"] / g["sst"]
    g["origins"] = d.groupby(["h", "model"])["T0"].nunique()
    w = d.pivot_table(index=["h", "T0"], columns="model", values="wape")
    wins = {int(h): {m: f"{int((w.loc[h][m] < w.loc[h]['Prophet']).sum())}/{len(w.loc[h])}"
                     for m in ("SNaive+g_shrunk", "Ensemble", "LGBM_direct", "Chronos-Bolt") if m in w.columns}
            for h in sorted(d["h"].unique())}
    return g[["MAE", "R2", "origins"]].reset_index(), wins


# %% основной сценарий
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data", nargs="?", default="data")
    ap.add_argument("out", nargs="?", default="outputs_forecast")
    ap.add_argument("--types", default=None, help="types_2023.csv из шага 2 (territory_id, type)")
    import sys
    in_notebook = "ipykernel" in sys.argv[0] or "colab" in sys.argv[0]
    args = ap.parse_args([] if in_notebook else None)   # в Jupyter/Colab берутся пути по умолчанию
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    cons, ma = load(args.data)
    w = to_wide(cons)
    dates = pd.DatetimeIndex(w.columns)
    Y = np.log(w.values.astype(float))
    meta = make_meta(w, ma)
    n_t = Y.shape[1]
    print(f"Рядов: {len(Y)} (МО × 6 категорий), месяцев: {n_t} ({dates[0]:%Y-%m} … {dates[-1]:%Y-%m})")
    med = pd.Series(np.median(Y[:, 12:] - Y[:, :12], axis=0), index=dates[12:].strftime("%Y-%m"))
    print("Медианный годовой рост, %:", (100 * (np.exp(med) - 1)).round(1).to_dict())

    print("\n== Признаки для LightGBM (все пары точка×горизонт)")
    blocks = build_blocks(Y, meta)
    print(f"блоков: {len(blocks)}")

    print("\n== Бэктест: скользящее начало прогноза")
    origins = range(11, n_t - 1)          # 11 = декабрь 2023 (точка из ноутбука команды)
    P, _ = run_backtest(Y, meta, blocks, origins)
    err = error_table(P, Y, meta, dates, sorted(P))
    err.to_csv(out / "backtest_errors_by_origin.csv", index=False)

    # 0) главная таблица задания: MAE и R² на горизонтах 1/3/6/12
    head = headline_table(err)
    head.to_csv(out / "headline_mae_r2.csv", index=False)
    print("\n== MAE, руб. на жителя в месяц (меньше — лучше). h=1,3,6: точки 2024 г.; h=12: одна точка дек-2023")
    for c in [TOTAL] + [x for x in head["category"].unique() if x != TOTAL]:
        t = head[head["category"] == c].pivot(index="model", columns="h", values="MAE").reindex(MODELS)
        print(f"\n-- {c}"); print(t.round(0).to_string())
    print("\n== R² («Все категории»; завышен различием уровней МО — смотреть вместе с MAE)")
    print(head[head["category"] == TOTAL].pivot(index="model", columns="h", values="R2").reindex(MODELS).round(3).to_string())

    # 0b) сравнение с Prophet на выборке рядов
    if CFG["prophet_n"]:
        idx = prophet_sample(meta, CFG["prophet_n"], CFG["seed"])
        t0 = time.time()
        PP = prophet_backtest(Y, dates, idx, list(origins), CFG["prophet_jobs"])
        print(f"\n== Prophet: {len(idx)} рядов × {len(origins)} точек прогноза, {time.time() - t0:.0f} c")
        t0 = time.time()
        PC, status = chronos_backtest(Y, idx, list(origins), CFG["chronos_model"])
        if PC is None:
            print(f"\n== Chronos-Bolt пропущен: {status}\n"
                  "   (веса качаются с huggingface.co; в Colab работает, в закрытой сети — нет)")
        else:
            print(f"\n== Chronos-Bolt ({CFG['chronos_model']}): {len(idx)} рядов, {time.time() - t0:.0f} c")
        cmp_, wins = compare_with_prophet(P, PP, Y, idx, extra={"Chronos-Bolt": PC} if PC else None)
        cmp_.to_csv(out / "prophet_comparison.csv", index=False)
        print("MAE, руб. (та же выборка рядов и те же точки для всех моделей):")
        print(cmp_.pivot(index="model", columns="h", values="MAE").round(0).to_string())
        print("R²:")
        print(cmp_.pivot(index="model", columns="h", values="R2").round(3).to_string())
        print("В скольких точках прогноза модель лучше Prophet:", wins)

    # 1) повтор схемы команды: одна точка (дек-2023), h = 1, 3, 6, 12
    team = err[err["T0"] == 11]
    _, macro_team, total_team = summarize(team, [1, 3, 6, 12])
    print("\n== Схема команды (одна точка, дек-2023): WAPE «Все категории», %")
    print(total_team.round(2).to_string())

    # 2) основная проверка: точки с января 2024, где рост уже наблюдаем
    main_err = err[err["T0"] >= CFG["first_origin"]]
    hs = [1, 2, 3, 6, 9, 11]
    sub, macro, total = summarize(main_err, hs)
    sub.round(3).to_csv(out / "metrics_by_category.csv", index=False)
    print("\n== Основная проверка: macro-WAPE по 5 категориям, % (меньше — лучше)")
    print(macro.round(2).to_string())
    print("\n== То же для «Все категории», %")
    print(total.round(2).to_string())
    print("\n== Смещение (bias), %, h=1 — знак показывает систематический недо/перепрогноз")
    print(sub[sub["h"] == 1].pivot(index="category", columns="model", values="bias_%")[MODELS].round(2).to_string())
    for ref in ("SNaive", "SNaive+g_shrunk"):
        print(f"\n== В скольких точках прогноза модель лучше {ref} (macro-WAPE)")
        print(wins_vs(main_err, ref, [1, 3, 6]).to_string())

    # 3) выбор модели на ранних точках, проверка на поздних
    cand = [m for m in MODELS if m != "Hybrid"]
    sel = summarize(main_err[main_err["T0"].isin(CFG["select_origins"])], [1, 2, 3])[1][cand].mean()
    hold = summarize(main_err[main_err["T0"].isin(CFG["holdout_origins"])], [1, 2, 3])[1]
    print(f"\n== Выбор на ранних точках {list(CFG['select_origins'])} (h=1..3): лучшая {sel.idxmin()}")
    print(sel.round(2).to_string())
    print("Проверка на поздних точках (macro-WAPE, %):")
    print(hold.round(2).to_string())
    e1 = main_err[(main_err["h"] == 1) & (main_err["category"] != TOTAL)].copy()
    e1["wape"] = 100 * e1["abs_err"] / e1["y"]
    gap = e1.groupby(["origin", "model"])["wape"].mean().unstack()
    gap = (gap["LGBM_direct"] - gap["SNaive+g_shrunk"]).round(2)
    print("Разница LightGBM − SNaive+g_shrunk по точкам, h=1, п.п. (LightGBM учится по мере накопления данных):")
    print(gap.to_string())
    # итоговая модель выбирается по MAE (метрика задания) на ранних точках, проверяется на поздних
    def pooled_mae(d):
        g = d.groupby("model")[["abs_err", "n"]].sum()
        return (g["abs_err"] / g["n"]).reindex(FINAL_CANDIDATES)
    sel_mae = pooled_mae(main_err[main_err["T0"].isin(CFG["select_origins"])])
    hold_mae = pooled_mae(main_err[main_err["T0"].isin(CFG["holdout_origins"])])
    best = sel_mae.idxmin()
    print("\n== Выбор итоговой модели по MAE (все ряды и горизонты 1–11), руб.:")
    print(pd.DataFrame({"ранние точки (выбор)": sel_mae, "поздние точки (проверка)": hold_mae}).round(0).to_string())
    print(f"Итоговая модель: {best}")
    j = MODELS.index(best)

    print("\n== 95% ДИ разницы macro-WAPE (п.п.), бутстрэп по МО; < 0 — первая модель лучше")
    ci_rows = []
    for h in (1, 3, 6):
        keys = [k for k in P if k[1] == h and k[0] >= CFG["first_origin"]]
        for a, b in [("SNaive+g_shrunk", "SNaive"), ("LGBM_direct", "SNaive+g_shrunk"),
                     ("SNaive+g_shrunk", "SNaive+g_MO")]:
            p, lo, hi = bootstrap_diff(P, Y, meta, keys, a, b)
            ci_rows.append(dict(h=h, compare=f"{a} − {b}", diff_pp=round(p, 3), ci_low=round(lo, 3), ci_high=round(hi, 3)))
    ci = pd.DataFrame(ci_rows)
    print(ci.to_string(index=False))
    ci.to_csv(out / "bootstrap_ci.csv", index=False)

    # 4) почему R² ≈ 0.99 ничего не говорит
    k = (11, 1)
    yt, yp = np.exp(Y[:, 12]), np.exp(P[k][:, MODELS.index("Naive")])
    r2 = 1 - ((yt - yp) ** 2).sum() / ((yt - yt.mean()) ** 2).sum()
    print(f"\n== Ловушка R²: у Naive на янв-2024 R² по уровням = {r2:.3f}, "
          f"а WAPE «Все категории» = {total_team.loc[1, 'Naive']:.1f}%")

    # 5) интервалы и сигналы
    cov = coverage_table(P, Y, meta, j)
    cov.to_csv(out / "interval_coverage.csv", index=False)
    print(f"\n== Покрытие {int(CFG['interval'] * 100)}% интервала ({best}), средн. по точкам:")
    print(cov.groupby("h")[["coverage_full", "coverage_peer", "shock_share_of_var"]].mean().round(3).head(6).to_string())
    sp = surprises(P, Y, meta, dates, j)
    sp.to_csv(out / "surprises_2024.csv", index=False)
    if len(sp):
        rep = sp[sp["category"] == TOTAL].groupby("territory_id").size().sort_values(ascending=False)
        print(f"\n== Сигналы отклонений: {len(sp)} случаев (|z|>{CFG['z_flag']}), "
              f"МО с ≥3 сигналами по «Все категории»: {(rep >= 3).sum()}")

    # 6) где прогноз хуже: доступность рынков и типы МО из шага 2
    keys1 = [k for k in P if k[1] == 1 and k[0] >= CFG["first_origin"]]
    ape = np.mean([np.abs(np.exp(-log_errors(P, Y, j, *kk)) - 1) for kk in keys1], axis=0)
    het = meta[["territory_id", "category", "log_ma"]].copy()
    het["APE_%"] = 100 * ape
    het["access_quintile"] = pd.qcut(het["log_ma"], 5, labels=["Q1 низкая", "Q2", "Q3", "Q4", "Q5 высокая"])
    print("\n== Медианная ошибка h=1 (%) по квинтилям доступности рынков:")
    print(het.pivot_table(index="access_quintile", columns="category", values="APE_%",
                          aggfunc="median", observed=True).round(2).to_string())
    if args.types and Path(args.types).exists():
        ty = pd.read_csv(args.types, dtype={"territory_id": str}).set_index("territory_id")["type"]
        het["type"] = het["territory_id"].map(ty)
        print("\n== Медианная ошибка h=1 (%) по типам МО из шага 2:")
        print(het.pivot_table(index="type", columns="category", values="APE_%",
                              aggfunc="median").round(2).to_string())
    het.to_csv(out / "error_by_mo.csv", index=False)

    # 7) итоговая модель на всех данных и прогноз на 2025 год
    T = n_t - 1
    final = train_lgbm(blocks, T)
    fc = []
    for h in range(1, 13):
        b = baselines(Y, T, h, meta["cat"].values)
        F, _ = features(Y, T, h, meta)
        b["LGBM_direct"] = Y[:, T + h - 12] + final.predict(pd.DataFrame(F, columns=FEATS))
        b["Hybrid"] = b["LGBM_direct"] if h <= HYBRID_MAX_H else b["SNaive+g_shrunk"]
        b["Ensemble"] = 0.5 * (b["LGBM_direct"] + b["SNaive+g_shrunk"])
        p = b[best]
        hc = h
        cal, n_or = calib_errors(P, Y, meta, j, hc, before=T)
        while cal is None and hc > 1:              # для h=12 ошибок ещё нет — берём ближайший горизонт
            hc -= 1
            cal, n_or = calib_errors(P, Y, meta, j, hc, before=T)
        df = meta[["territory_id", "category"]].copy()
        df["date"] = (dates[-1] + pd.DateOffset(months=h)).strftime("%Y-%m")
        df["h"] = h
        df["forecast"] = np.exp(p)
        E, C = cal
        for c in np.unique(meta["cat"]):
            q = np.quantile(np.abs(E[C == c]), CFG["interval"])
            s = meta["cat"].values == c
            df.loc[s, "lo"] = np.exp(p[s] - q)
            df.loc[s, "hi"] = np.exp(p[s] + q)
        df["interval_from_h"] = hc
        df["interval_calib_origins"] = n_or
        df["interval_reliability"] = "ok" if n_or >= 6 else "low (мало точек проверки)"
        fc.append(df)
    fc = pd.concat(fc, ignore_index=True)
    fc[["forecast", "lo", "hi"]] = fc[["forecast", "lo", "hi"]].round(0)
    fc["model"] = best
    fc.to_csv(out / "forecast_2025.csv", index=False)
    print(f"\nПрогноз на 2025 ({best}): forecast_2025.csv, {len(fc)} строк")

    imp = pd.Series(final.booster_.feature_importance("gain"), index=FEATS).sort_values()
    imp = 100 * imp / imp.sum()
    print("\n== Важность признаков LightGBM (gain, %):")
    print(imp[::-1].round(1).to_string())

    # картинки
    fig, ax = plt.subplots(figsize=(7, 4.2))
    for m in MODELS:
        ax.plot(macro.index, macro[m], marker="o", lw=2.4 if m == best else 1.2, label=m)
    ax.set_xlabel("горизонт, мес."); ax.set_ylabel("macro-WAPE, % (5 категорий)")
    ax.set_title("Ошибка прогноза по горизонтам (скользящее начало, 2024)")
    ax.set_yscale("log"); ax.grid(alpha=.3); ax.legend(fontsize=8, ncol=2)
    fig.tight_layout(); fig.savefig(out / "wape_by_horizon.png", dpi=150); plt.close(fig)

    piv = sub[sub["h"].isin([1, 3, 6])].pivot_table(index="category", columns=["h", "model"], values="WAPE_%")
    skill = pd.concat({h: 100 * (1 - piv[h].div(piv[h]["SNaive"], axis=0)) for h in (1, 3, 6)}, axis=1)
    skill = skill.drop(columns=[(h, "SNaive") for h in (1, 3, 6)])
    fig, ax = plt.subplots(figsize=(12, 3.8))
    im = ax.imshow(skill.values, cmap="RdBu", vmin=-60, vmax=60, aspect="auto")
    ax.set_xticks(range(skill.shape[1]))
    ax.set_xticklabels([f"h={h}\n{m}" for h, m in skill.columns], fontsize=7, rotation=45, ha="right")
    ax.set_yticks(range(skill.shape[0])); ax.set_yticklabels(skill.index)
    for i in range(skill.shape[0]):
        for k2 in range(skill.shape[1]):
            ax.text(k2, i, f"{skill.values[i, k2]:.0f}", ha="center", va="center", fontsize=7)
    ax.set_title("Выигрыш против сезонной наивной, % снижения WAPE (синий — лучше)")
    fig.colorbar(im); fig.tight_layout(); fig.savefig(out / "skill_vs_snaive.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    imp.plot.barh(ax=ax); ax.set_xlabel("доля gain, %"); ax.set_title("LightGBM: важность признаков (gain)")
    fig.tight_layout(); fig.savefig(out / "lgbm_importance.png", dpi=150); plt.close(fig)

    macro.round(3).to_csv(out / "summary_macro_wape.csv")
    total.round(3).to_csv(out / "summary_total_wape.csv")
    total_team.round(3).to_csv(out / "team_scheme_single_origin_total_wape.csv")
    print(f"\nГотово: {out.resolve()}")


if __name__ == "__main__":
    main()
