"""ШАГ 5. Новости: как согласовать их с данными СберИндекса и сколько они дают для раннего обнаружения шоков.

Запуск:   python forecast/news.py data outputs_news [--news news.csv --gazetteer gazetteer.csv]
Время:    ~1 минута.

Часть A — конвейер согласования (рабочий код; запускается на реальной ленте новостей, если она есть):
  1. ГЕОПРИВЯЗКА. Новость -> МО по справочнику названий (топоним в тексте, проверка региона при неоднозначности).
     Без справочника «territory_id -> название МО» привязка невозможна: коды в данных — не ОКТМО.
  2. ТИП СОБЫТИЯ. Правила по ключевым словам (закрытие/открытие предприятия, ЧС, инфраструктура, выплаты...)
     с ожидаемым знаком влияния и затронутыми категориями. Улучшение — классификация языковой моделью.
  3. ВРЕМЯ. Данные СберИндекса месячные. Новость, опубликованная в месяце t, может использоваться в прогнозе
     только с точки T0 >= t (никакой утечки из будущего). Анонсированные события с датой («откроется в мае»)
     идут как известное заранее событие в месяц наступления — это и есть «заранее выявить предстоящий шок».
  4. ИСПОЛЬЗОВАНИЕ. (а) Признаки МО×месяц для прогноза; (б) подсказка детектору: в окне 3 мес. после новости
     порог срабатывания снижается.
  5. ПРОВЕРКА. Событийный анализ: средний остаток TWFE (отклонение МО от остальных) за -3..+3 мес. вокруг
     новостей против случайных «плацебо»-дат.

Часть B — сколько стоят новости (симуляция, НЕ реальные новости):
  На 3000 реальных рядов вставляем ступеньку 10/20% в случайный месяц и генерируем «новостные флаги» заданного
  качества: доля шоков, о которых была новость (полнота новостей), и доля рядов с ложной новостью.
  Онлайн-детектор с новостями и без калибруется на одинаковую долю ложных тревог (10% рядов).
  Ответ: при каком качестве новостного потока он реально ускоряет и улучшает обнаружение.
"""
# %% импорты и настройки
import argparse
import re
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
except NameError:
    sys.path[:0] = [str(Path.cwd()), str(Path.cwd() / "forecast")]
from forecast_v2 import load, make_meta, to_wide   # noqa: E402
from changepoints import CFG as CP_CFG, cusum_all, idiosyncratic, inject, standardize   # noqa: E402

NEWS_CFG = dict(
    n_series=3000,
    sizes=(0.10, 0.20),
    news_recall=(0.3, 0.6, 0.9),     # доля шоков, о которых была новость
    false_rate=(0.05, 0.20),         # доля рядов с ложной новостью (за весь период)
    news_window=3,                   # сколько месяцев после новости порог снижен
    news_factor=0.5,                 # во сколько раз снижается порог при новости
    target_alarm=0.10,
    window_k=1,                      # детектор «сдвиг окна»: k последних месяцев против 6 предыдущих
    window_before=6,
    seed=11,
)

# Типы событий: ключевые слова (корни), ожидаемый знак влияния на расходы, затронутые категории.
# Порядок важен: сначала частные типы, в конце общие «закрытие/открытие предприятия».
EVENT_TYPES = {
    "ЧС": (r"паводок|наводнени|пожар|чрезвычайн|эвакуац|подтоплен", -1, ["Все категории", "Транспорт"]),
    "торговля": (r"торгов(ый|ого) центр|гипермаркет|супермаркет|пункт выдачи|ПВЗ", +1,
                 ["Продовольствие", "Маркетплейсы"]),
    "транспорт": (r"мост|трасс|дорог|автобус|электричк|паром", +1, ["Транспорт"]),
    "выплаты": (r"выплат|пособи|индексаци|зарплат", +1, ["Все категории"]),
    "здравоохранение": (r"больниц|поликлиник|аптек|ФАП", +1, ["Здоровье"]),
    "туризм_общепит": (r"туристическ|курорт|фестивал|ресторан|кафе", +1, ["Общественное питание"]),
    "закрытие_предприятия": (r"закры|банкрот|сокращени|увольнен|простой", -1, ["Все категории"]),
    "открытие_предприятия": (r"открыл|открыт|запуск|нов(ый|ого) завод|рабочих мест", +1, ["Все категории"]),
}


# %% часть A: конвейер согласования новостей с данными
def normalize(text):
    return re.sub(r"\s+", " ", str(text).lower().replace("ё", "е"))


def link_news_to_mo(news, gazetteer):
    """news: date, text[, region]; gazetteer: territory_id, name, region.
    Привязка по названию МО в тексте (целым словом, с учётом падежных окончаний: первые ≥5 букв основы).
    Если одно название у нескольких МО — оставляем ту, чей регион упомянут; иначе помечаем как неоднозначную."""
    g = gazetteer.copy()
    g["stem"] = g["name"].map(lambda s: normalize(s)[:max(5, len(normalize(s)) - 2)])
    rows = []
    for _, n in news.iterrows():
        txt = normalize(n["text"])
        hits = g[g["stem"].map(lambda st: re.search(rf"\b{re.escape(st)}", txt) is not None)]
        if len(hits) > 1 and "region" in g:
            in_reg = hits[hits["region"].map(lambda r: normalize(r)[:6] in txt)]
            hits = in_reg if len(in_reg) else hits
        for _, h in hits.iterrows():
            rows.append({**n.to_dict(), "territory_id": str(h["territory_id"]),
                         "confidence": "однозначно" if len(hits) == 1 else "неоднозначно"})
    return pd.DataFrame(rows)


def classify_event(text):
    """Тип события по ключевым словам -> (тип, знак, категории). Прозрачно и проверяемо; можно заменить на LLM."""
    t = normalize(text)
    for name, (pat, sign, cats) in EVENT_TYPES.items():
        if re.search(pat.lower(), t):
            return name, sign, cats
    return "прочее", 0, []


def news_features(linked, months, event_date_col=None):
    """Признаки МО×месяц: число новостей каждого типа, опубликованных в месяце (без утечки: используются в
    прогнозе только с точки T0 >= месяц публикации). Если есть дата наступления события (анонс), событие
    дополнительно ставится в месяц наступления как «известное заранее»."""
    if linked.empty:
        return pd.DataFrame()
    d = linked.copy()
    d[["event", "sign", "cats"]] = d["text"].apply(lambda s: pd.Series(classify_event(s)))
    d["month"] = pd.to_datetime(d["date"]).dt.to_period("M").dt.to_timestamp()
    d = d[d["month"].isin(months)]
    f = d.pivot_table(index=["territory_id", "month"], columns="event", values="text", aggfunc="count", fill_value=0)
    f.columns = [f"news_{c}" for c in f.columns]
    f["news_signed"] = d.groupby(["territory_id", "month"])["sign"].sum()
    if event_date_col and event_date_col in d:
        ev = d.dropna(subset=[event_date_col]).copy()
        ev["event_month"] = pd.to_datetime(ev[event_date_col]).dt.to_period("M").dt.to_timestamp()
        known = ev.groupby(["territory_id", "event_month"]).size().rename("known_future_event")
        f = f.join(known.rename_axis(["territory_id", "month"]), how="outer").fillna(0)
    return f.reset_index()


def event_study(D, meta, dates, events, window=3, n_placebo=2000, seed=0):
    """Средний остаток TWFE (отклонение МО от остальных, лог) за -window..+window мес. вокруг события,
    нормированный на уровень до события, против случайных плацебо-дат. events: territory_id, month[, category]."""
    rng = np.random.default_rng(seed)
    pos = {m: i for i, m in enumerate(dates)}
    key = {(t, c): i for i, (t, c) in enumerate(zip(meta["territory_id"], meta["category"]))}

    def path(i, t):
        if t - window < 0 or t + window >= D.shape[1]:
            return None
        seg = D[i, t - window:t + window + 1]
        return seg - seg[:window].mean()

    ev = []
    for _, e in events.iterrows():
        i = key.get((str(e["territory_id"]), e.get("category", "Все категории")))
        t = pos.get(pd.Timestamp(e["month"]))
        if i is not None and t is not None and (p := path(i, t)) is not None:
            ev.append(p)
    pl = [p for _ in range(n_placebo)
          if (p := path(rng.integers(len(D)), rng.integers(window, D.shape[1] - window))) is not None]
    rel = np.arange(-window, window + 1)
    return pd.DataFrame({"month_rel": rel,
                         "events_mean_pct": 100 * (np.exp(np.mean(ev, axis=0)) - 1) if ev else np.nan,
                         "placebo_mean_pct": 100 * (np.exp(np.mean(pl, axis=0)) - 1),
                         "placebo_sd_pct": 100 * np.std(pl, axis=0)}), len(ev)


# %% часть B: онлайн-детектор и ценность новостей (симуляция)
def window_shift_all(Z, h, k=1, n_before=6, news=None, factor=0.5):
    """Онлайн-детектор «сдвиг окна»: в каждый месяц t сравниваем среднее последних k месяцев со средним
    n_before месяцев до них (только прошлые данные). При новости (news[i, t]=True) порог ниже в factor раз.
    Возвращает месяц первой тревоги (или -1)."""
    S, T = Z.shape
    alarm = np.full(S, -1)
    for t in range(n_before + k - 1, T):
        after = Z[:, t - k + 1:t + 1].mean(axis=1)
        before = Z[:, t - k - n_before + 1:t - k + 1].mean(axis=1)
        stat = np.abs(after - before) / np.sqrt(1 / k + 1 / n_before)
        thr = h if news is None else np.where(news[:, t], h * factor, h)
        new = (alarm < 0) & (stat > thr)
        alarm[new] = t
    return alarm


def calibrate(fn, Z, target, grid):
    for h in grid:
        r = np.mean(fn(Z, h) >= 0)
        if r <= target:
            return h, r
    return grid[-1], r


def news_mask(S, T, taus, has_news, false_flag, rng, window):
    """Флаги новостей: настоящие — в месяц шока или за месяц до него (анонс); ложные — в случайный месяц."""
    M = np.zeros((S, T), bool)
    for i in range(S):
        starts = []
        if has_news[i]:
            starts.append(taus[i] - rng.integers(0, 2))
        if false_flag[i]:
            starts.append(rng.integers(0, T))
        for s in starts:
            M[i, max(s, 0):min(s + window, T)] = True
    return M


def score(alarm, taus, win):
    ok = (alarm >= taus) & (alarm <= taus + win)
    return ok.mean(), ((alarm - taus)[ok]).mean() if ok.any() else np.nan


def news_value(D, S_scale, cfg=NEWS_CFG, cp=CP_CFG):
    rng = np.random.default_rng(cfg["seed"])
    idx = rng.choice(len(D), min(cfg["n_series"], len(D)), replace=False)
    Z, mult = standardize(D[idx], S_scale[idx])
    S, T = Z.shape
    taus = rng.integers(*cp["tau_range"], size=S)
    grid = np.round(np.geomspace(0.5, 200, 80), 3)
    win = cp["online_window"]
    k, nb = cfg["window_k"], cfg["window_before"]

    h_cusum, _ = calibrate(lambda z, h: cusum_all(z, h), Z, cfg["target_alarm"], grid)
    h_win, _ = calibrate(lambda z, h: window_shift_all(z, h, k, nb), Z, cfg["target_alarm"], grid)
    rows = []
    for size in cfg["sizes"]:
        Z2 = inject(Z, mult, taus, size)
        for name, a in [("CUSUM", cusum_all(Z2, h_cusum)), ("Сдвиг окна", window_shift_all(Z2, h_win, k, nb))]:
            rec, dl = score(a, taus, win)
            rows.append(dict(shock=f"{size:.0%}", detector=name, news_recall="—", false_news="—",
                             recall=rec, delay=dl))
        for r in cfg["news_recall"]:
            for f in cfg["false_rate"]:
                has = rng.random(S) < r
                fake = rng.random(S) < f
                M = news_mask(S, T, taus, has, fake, rng, cfg["news_window"])
                # калибровка с новостями: на чистых рядах есть только ложные флаги
                M0 = news_mask(S, T, taus, np.zeros(S, bool), fake, rng, cfg["news_window"])
                h_n, _ = calibrate(lambda z, h: window_shift_all(z, h, k, nb, M0, cfg["news_factor"]),
                                   Z, cfg["target_alarm"], grid)
                a = window_shift_all(Z2, h_n, k, nb, M, cfg["news_factor"])
                rec, dl = score(a, taus, win)
                rows.append(dict(shock=f"{size:.0%}", detector="Сдвиг окна + новости",
                                 news_recall=f"{r:.0%}", false_news=f"{f:.0%}", recall=rec, delay=dl))
    return pd.DataFrame(rows)


# %% основной сценарий
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data", nargs="?", default="data")
    ap.add_argument("out", nargs="?", default="outputs_news")
    ap.add_argument("--news", default=None, help="CSV: date, text[, region, event_date]")
    ap.add_argument("--gazetteer", default=None, help="CSV: territory_id, name, region")
    in_notebook = "ipykernel" in sys.argv[0] or "colab" in sys.argv[0]
    args = ap.parse_args([] if in_notebook else None)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    cons, ma = load(args.data)
    w = to_wide(cons)
    dates = pd.DatetimeIndex(w.columns)
    Y = np.log(w.values.astype(float))
    meta = make_meta(w, ma)
    k = CP_CFG["skip_first"]
    D = idiosyncratic(Y, meta["cat"].values)[:, k:]
    S_scale = np.ones_like(D)

    # часть B
    print("== Ценность новостей для онлайн-обнаружения (симуляция на 3000 реальных рядов, 10% ложных тревог)")
    res = news_value(D, S_scale)
    res.to_csv(out / "news_value_simulation.csv", index=False)
    print(res.round(3).to_string(index=False))

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8), sharey=True)
    for ax, size in zip(axes, NEWS_CFG["sizes"]):
        d = res[res["shock"] == f"{size:.0%}"]
        base = d[d["detector"] == "Сдвиг окна"]["recall"].iat[0]
        cus = d[d["detector"] == "CUSUM"]["recall"].iat[0]
        for f in NEWS_CFG["false_rate"]:
            x = d[(d["detector"] == "Сдвиг окна + новости") & (d["false_news"] == f"{f:.0%}")]
            ax.plot(x["news_recall"], x["recall"], marker="o", label=f"с новостями, ложных {f:.0%}")
        ax.axhline(base, ls="--", c="gray", label="без новостей (сдвиг окна)")
        ax.axhline(cus, ls=":", c="black", label="CUSUM")
        ax.set_title(f"Шок {size:.0%}"); ax.set_xlabel("доля шоков, о которых была новость"); ax.grid(alpha=.3)
    axes[0].set_ylabel("доля шоков, пойманных за ≤3 мес."); axes[0].set_ylim(0, 1); axes[1].legend(fontsize=7)
    fig.suptitle("Сколько дают новости раннему обнаружению (при 10% ложных тревог)", fontsize=10)
    fig.tight_layout(); fig.savefig(out / "news_value.png", dpi=150); plt.close(fig)

    # часть A на реальной ленте, если она передана
    if args.news and args.gazetteer:
        news = pd.read_csv(args.news)
        gaz = pd.read_csv(args.gazetteer, dtype={"territory_id": str})
        linked = link_news_to_mo(news, gaz)
        feats = news_features(linked, dates, "event_date" if "event_date" in news else None)
        linked.to_csv(out / "news_linked.csv", index=False)
        feats.to_csv(out / "news_features.csv", index=False)
        ev = linked.assign(month=pd.to_datetime(linked["date"]).dt.to_period("M").dt.to_timestamp())
        es, n_ev = event_study(idiosyncratic(Y, meta["cat"].values), meta, dates, ev)
        es.to_csv(out / "news_event_study.csv", index=False)
        print(f"\n== Новости: привязано {len(linked)} к МО; событийный анализ по {n_ev} событиям:")
        print(es.round(2).to_string(index=False))
    else:
        print("\nЛента новостей и справочник названий МО не переданы — часть A (привязка, признаки, "
              "событийный анализ) готова к запуску: --news news.csv --gazetteer gazetteer.csv")
    print(f"\nГотово: {out.resolve()}")


if __name__ == "__main__":
    main()
