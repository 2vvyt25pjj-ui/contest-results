"""Собирает единый ноутбук SberIndex_project.ipynb из модулей проекта.

Запуск: python tools/build_notebook.py   (затем jupyter nbconvert --execute для вывода результатов)
Исходники остаются в typology/ и forecast/; ноутбук — их склейка с пояснениями, правится через модули.
"""
import ast
import re
from pathlib import Path

import jupytext

ROOT = Path(__file__).resolve().parent.parent


def strip_docstring(src):
    tree = ast.parse(src)
    if tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(getattr(tree.body[0], "value", None), ast.Constant):
        end = tree.body[0].end_lineno
        return "\n".join(src.splitlines()[end:]).lstrip("\n")
    return src


def strip_main_guard(src):
    return re.sub(r'\nif __name__ == "__main__":\n    main\(\)\n?', "\n", src)


def rename(src, old, new):
    return re.sub(rf"\b{old}\b", new, src)


def audit_src():
    s = strip_docstring((ROOT / "typology/step1_audit.py").read_text())
    s = s.replace('D = Path(sys.argv[1] if len(sys.argv) > 1 else "data")', "D = Path(DATA_DIR)")
    s = s.replace('Path("audit_report.txt").write_text', '(Path(OUT_DIR) / "audit_report.txt").write_text')
    s = s.replace('print("\\nОтчёт сохранён: audit_report.txt")', 'print(f"\\nОтчёт сохранён: {OUT_DIR}/audit_report.txt")')
    return "# %% аудит данных\n" + s


def typology_src():
    s = strip_main_guard(strip_docstring((ROOT / "typology/step2_baseline.py").read_text()))
    s = rename(s, "CFG", "TY_CFG")
    s = s.replace('def main():\n    data = Path(sys.argv[1] if len(sys.argv) > 1 else "data")\n'
                  '    out = sys.argv[2] if len(sys.argv) > 2 else "outputs"',
                  'def typology_main(data=None, out=None):\n    data = Path(data or DATA_DIR)\n'
                  '    out = out or f"{OUT_DIR}/typology"')
    return "# %% типология: функции\n" + s


def forecast_src():
    s = strip_main_guard(strip_docstring((ROOT / "forecast/forecast_v2.py").read_text()))
    s = rename(s, "CFG", "FC_CFG")
    s = re.sub(r"def main\(\):\n    ap = argparse.ArgumentParser\(\)\n.*?    args = ap.parse_args\(\[\] if in_notebook else None\).*?\n",
               "def forecast_main(data=None, out=None, types=None):\n"
               "    args = argparse.Namespace(data=data or DATA_DIR, out=out or f\"{OUT_DIR}/forecast\", types=types)\n",
               s, flags=re.S)
    assert "def forecast_main" in s
    return s


def changepoints_src():
    s = strip_main_guard(strip_docstring((ROOT / "forecast/changepoints.py").read_text()))
    s = re.sub(r"try:\n    sys.path.insert.*?from forecast_v2 import [^\n]*\n", "", s, flags=re.S)
    s = rename(s, "CFG", "CP_CFG")
    s = re.sub(r"def main\(\):\n    ap = argparse.ArgumentParser\(\)\n.*?    args = ap.parse_args\(\[\] if in_notebook else None\)\n",
               "def changepoints_main(data=None, out=None, surprises=None):\n"
               "    args = argparse.Namespace(data=data or DATA_DIR, out=out or f\"{OUT_DIR}/changepoints\",\n"
               "                              surprises=surprises or f\"{OUT_DIR}/forecast/surprises_2024.csv\")\n",
               s, flags=re.S)
    assert "def changepoints_main" in s and "from forecast_v2" not in s
    return s


def news_src():
    s = strip_main_guard(strip_docstring((ROOT / "forecast/news.py").read_text()))
    s = re.sub(r"try:\n    sys.path.insert.*?from changepoints import [^\n]*\n", "", s, flags=re.S)
    s = re.sub(r"def main\(\):\n    ap = argparse.ArgumentParser\(\)\n.*?    args = ap.parse_args\(\[\] if in_notebook else None\)\n",
               "def news_main(data=None, out=None, news=None, gazetteer=None):\n"
               "    args = argparse.Namespace(data=data or DATA_DIR, out=out or f\"{OUT_DIR}/news\", news=news, gazetteer=gazetteer)\n",
               s, flags=re.S)
    assert "def news_main" in s and "from changepoints" not in s
    return s


def md(text):
    lines = text.strip("\n").splitlines()
    return "# %% [markdown]\n" + "\n".join("# " + l if l else "#" for l in lines) + "\n"


def build():
    doc = (ROOT / "tools/notebook_text.md").read_text()
    parts = dict(re.findall(r"<!-- (\w+) -->\n(.*?)(?=\n<!-- |\Z)", doc, flags=re.S))
    cells = [
        md(parts["intro"]),
        "# %% подготовка: библиотеки и данные\n" + (ROOT / "tools/setup_cell.py").read_text(),
        md(parts["audit"]), audit_src(),
        md(parts["typology"]), typology_src(), "# %% запуск типологии\ntypology_main()\n",
        md(parts["forecast"]), forecast_src(),
        "# %% запуск прогноза (около 5 минут: 11 обучений LightGBM + 7200 обучений Prophet)\n"
        "forecast_main(types=f\"{OUT_DIR}/typology/types_2023.csv\")\n",
        md(parts["changepoints"]), changepoints_src(), "# %% запуск поиска переломов\nchangepoints_main()\n",
        md(parts["news"]), news_src(),
        "# %% запуск: онлайн-детекторы и ценность новостей (симуляция). С реальной лентой:\n"
        "# news_main(news=\"news.csv\", gazetteer=\"gazetteer.csv\")\nnews_main()\n",
        md(parts["figures"]),
        "# %% показать ключевые графики\nfrom IPython.display import Image, display\n"
        "for f in [\"forecast/wape_by_horizon.png\", \"forecast/skill_vs_snaive.png\", \"changepoints/detector_recall.png\",\n"
        "          \"news/news_value.png\", \"changepoints/break_examples.png\", \"typology/type_profiles.png\"]:\n"
        "    print(f); display(Image(filename=f\"{OUT_DIR}/{f}\", width=800))\n",
        md(parts["conclusions"]),
    ]
    src = "\n\n".join(cells)
    # проверка: нет конфликтов имён верхнего уровня между частями
    names = {}
    for n in ast.parse(src).body:
        if isinstance(n, (ast.FunctionDef, ast.ClassDef)):
            names.setdefault(n.name, 0)
            names[n.name] += 1
    dup = {k: v for k, v in names.items() if v > 1 and k not in {"fix_value_column", "read_optional", "say"}}
    assert not dup, f"конфликт имён: {dup}"
    py = ROOT / "SberIndex_project.py"
    py.write_text(src)
    nb = jupytext.read(py, fmt="py:percent")
    jupytext.write(nb, ROOT / "SberIndex_project.ipynb")
    py.unlink()
    print("собрано: SberIndex_project.ipynb")


if __name__ == "__main__":
    build()
