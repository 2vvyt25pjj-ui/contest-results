# ШАГ 0. Подготовка. Просто выполните эту ячейку.
# 1) ставит нужные библиотеки (около 2–3 минут в Colab);
# 2) если файлов данных нет — в Colab появится кнопка «Выбрать файлы»: выберите consumption.parquet и market_access.parquet.
import argparse, os, shutil, subprocess, sys, time
from pathlib import Path

subprocess.run([sys.executable, "-m", "pip", "install", "-q", "pandas", "pyarrow", "numpy", "lightgbm", "scikit-learn",
                "networkx", "matplotlib", "ruptures", "prophet", "chronos-forecasting"], check=False)

DATA_DIR = "data"
OUT_DIR = "outputs"
Path(DATA_DIR).mkdir(exist_ok=True)
Path(OUT_DIR).mkdir(exist_ok=True)
need = ["consumption.parquet", "market_access.parquet"]
missing = [f for f in need if not (Path(DATA_DIR) / f).exists()]
if missing and "google.colab" in sys.modules:
    from google.colab import files
    print("Выберите файлы:", ", ".join(missing))
    for name in files.upload():
        target = next((f for f in need if f.split(".")[0] in name), name)   # «consumption (1).parquet» тоже подойдёт
        shutil.move(name, Path(DATA_DIR) / target)
missing = [f for f in need if not (Path(DATA_DIR) / f).exists()]
print("Данные на месте" if not missing else f"НЕ ХВАТАЕТ ФАЙЛОВ в папке data/: {missing}")
