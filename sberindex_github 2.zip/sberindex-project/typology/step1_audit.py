"""ШАГ 1. Аудит данных СберИндекса. Занимает ~15 минут и делается ДО любого моделирования.

Запуск:   python step1_audit.py data
          (data — папка, где лежат consumption.parquet, market_access.parquet, connection.parquet)
Результат: печать в консоль + файл audit_report.txt

Главный вопрос шага: как устроен territory_id и можно ли по нему склеить Росстат (ОКТМО).
"""
import sys
from pathlib import Path
import pandas as pd

D = Path(sys.argv[1] if len(sys.argv) > 1 else "data")
lines = []


def say(s=""):
    print(s)
    lines.append(str(s))




def read_optional(name):
    f = D / f"{name}.parquet"
    if not f.exists():
        say(f"(файла {f.name} нет — пропускаю связанные проверки)")
        return None
    return pd.read_parquet(f)


def fix_value_column(df):
    """Если столбца 'consumption' нет — находим единственный числовой столбец-значение и переименовываем."""
    if "consumption" in df.columns:
        return df
    skip = {"territory_id", "date", "category"}
    num = [c for c in df.columns if c not in skip and pd.api.types.is_numeric_dtype(df[c])]
    if len(num) == 1:
        say(f"ВНИМАНИЕ: столбца 'consumption' нет, использую '{num[0]}' как значение расходов")
        return df.rename(columns={num[0]: "consumption"})
    raise SystemExit(f"Не нашёл столбец со значениями расходов. Столбцы в файле: {list(df.columns)}")


cons = pd.read_parquet(D / "consumption.parquet")
say(f"Столбцы consumption.parquet: {list(cons.columns)}")
cons = fix_value_column(cons)
ma = read_optional("market_access")
con = read_optional("connection")

say("== 1. Размеры и типы столбцов")
for name, df in [("consumption", cons), ("market_access", ma), ("connection", con)]:
    if df is None:
        continue
    say(f"\n{name}: {df.shape[0]:,} строк x {df.shape[1]} столбцов")
    say(df.dtypes.to_string())
    say(df.head(3).to_string())

say("\n== 2. Формат territory_id (КЛЮЧЕВОЕ для склейки с Росстатом по ОКТМО)")
ids = pd.Series(cons["territory_id"].unique())
s = ids.astype(str)
say(f"уникальных МО: {len(ids)}; тип: {cons['territory_id'].dtype}; примеры: {list(s.head(5))}")
say("распределение длин кода:\n" + s.str.len().value_counts().sort_index().to_string())
digits_share = s.str.fullmatch(r"\d+").mean()
say(f"доля кодов только из цифр: {digits_share:.3f}")
say("Как читать: коды длиной 8 (иногда 7, если потерян ведущий ноль) и только из цифр —")
say("похоже на ОКТМО, склейка с Росстатом возможна. Иначе нужен справочник СберИндекса.")

say("\n== 3. Период и категории")
cons["date"] = pd.to_datetime(cons["date"])
say(f"период: {cons['date'].min():%Y-%m} … {cons['date'].max():%Y-%m}; месяцев: {cons['date'].nunique()}")
say(cons["category"].value_counts().to_string())

say("\n== 4. Полнота панели")
n_cells = cons["date"].nunique() * cons["category"].nunique()
per_mo = cons.groupby("territory_id").size()
say(f"МО с полным набором (месяцы x категории = {n_cells}): {(per_mo == n_cells).sum()} из {len(per_mo)}")
say(f"дубликаты (МО, дата, категория): {cons.duplicated(['territory_id', 'date', 'category']).sum()}")

say("\n== 5. Значения")
c = cons["consumption"]
say(f"пропуски: {c.isna().sum()}; нули или отрицательные: {(c <= 0).sum()}")
say(cons.groupby("category")["consumption"].describe(percentiles=[.01, .5, .99]).round(0).to_string())

say("\n== 6. Доли категорий в «Все категории» и календарный эффект")
piv = cons.pivot_table(index=["territory_id", "date"], columns="category", values="consumption")
all_cols = [x for x in piv.columns if "все" in str(x).lower()]
if all_cols:
    tot = piv[all_cols[0]]
    others = piv.drop(columns=all_cols)
    say("средняя доля категории в «Все категории»:")
    say((others.div(tot, axis=0)).mean().round(3).to_string())
    say(f"доля, не попавшая в 5 категорий («прочее»): {(1 - others.sum(axis=1) / tot).mean():.3f}")
    say("медиана «Все категории» по месяцам (видны сезонность и тренд — их надо вычитать):")
    say(tot.groupby(level="date").median().round(0).to_string())
else:
    say("столбец «Все категории» не найден — проверь названия категорий выше")

say("\n== 7. Пересечение МО между файлами")
a = set(cons["territory_id"].astype(str))
say(f"consumption: {len(a)} МО")
if ma is not None:
    b = set(ma["territory_id"].astype(str))
    say(f"market_access: {len(b)}; consumption ∩ market_access: {len(a & b)}; consumption без market_access: {len(a - b)}")
if con is not None:
    x = set(con["territory_id_x"].astype(str)) | set(con["territory_id_y"].astype(str))
    say(f"connection: {len(x)}; consumption ∩ connection: {len(a & x)}")

Path("audit_report.txt").write_text("\n".join(lines), encoding="utf-8")
print("\nОтчёт сохранён: audit_report.txt")
