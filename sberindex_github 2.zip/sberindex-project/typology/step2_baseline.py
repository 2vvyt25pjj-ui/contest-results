"""ШАГ 2. Базовый прототип: признаки -> граф «двойников» -> типы МО -> переходы 2023 -> 2024.

Запуск:   python step2_baseline.py data outputs
Установка: pip install pandas pyarrow scikit-learn networkx matplotlib

Что делает (всё на файлах СберИндекса, без Росстата):
  1. строит панель МО x месяц x категория, оставляет МО с полным рядом;
  2. считает 6 признаков за каждый год, вычитая общий для всех МО месячный сдвиг
     (календарь + инфляция), и стандартизует;
  3. строит граф: ребро между МО, если они среди k ближайших друг для друга;
  4. находит типы алгоритмом Louvain (на этом шаге он проще в установке, чем Leiden);
  5. проверяет устойчивость и чувствительность, сравнивает с K-means;
  6. относит МО 2024 года к типам 2023 года и строит матрицу переходов.
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

CFG = dict(
    k=10,                 # число ближайших соседей
    mutual=True,          # ребро только если соседство взаимное
    metric="euclidean",   # расстояние между МО (как в британской модели CIPFA)
    resolution=None,      # «крупность» типов в Louvain; None = подобрать по silhouette (см. ниже)
    k_types=(3, 10),      # допустимое число типов при автоподборе
    min_size=15,          # типы меньше этого размера вливаются в ближайший
    seed=42,
)

# по каким подстрокам искать категории (регистр не важен)
CAT_KEYS = {"total": "все", "food": "продов", "health": "здоров",
            "cater": "общ", "transport": "транспорт", "market": "маркет"}
SHARES = ["food", "health", "cater", "transport", "market"]


# ----------------------------------------------------------------- данные
def find_categories(cons):
    names = list(cons["category"].unique())
    out = {}
    for key, sub in CAT_KEYS.items():
        hit = [n for n in names if sub in str(n).lower()]
        if len(hit) != 1:
            raise ValueError(f"Не смог однозначно найти категорию '{key}' (подстрока '{sub}'). "
                             f"Категории в файле: {names}. Поправь CAT_KEYS.")
        out[key] = hit[0]
    return out


def monthly_wide(cons, cats):
    c = cons.copy()
    c["date"] = pd.to_datetime(c["date"])
    w = c.pivot_table(index=["territory_id", "date"], columns="category",
                      values="consumption", aggfunc="mean")
    return w.rename(columns={v: k for k, v in cats.items()})[list(cats)]


def full_panel(w):
    """Оставляем МО, у которых во всех месяцах все категории > 0 (пропуски и нули выбрасываем)."""
    w = w[(w > 0).all(axis=1)]
    n = w.groupby(level="territory_id").size()
    return w.loc[n[n == n.max()].index]


def month_features(w):
    f = pd.DataFrame(index=w.index)
    f["log_total"] = np.log(w["total"])
    for c in SHARES:
        f["share_" + c] = w[c] / w["total"]
    return f


def year_features(w, year):
    f = month_features(w)
    f = f - f.groupby(level="date").transform("median")   # вычитаем общий месячный сдвиг
    f = f[f.index.get_level_values("date").year == year]
    return f.groupby(level="territory_id").mean()


def add_access(X, ma):
    s = ma.drop_duplicates("territory_id").set_index("territory_id")["market_access"]
    s = np.log1p(s.reindex(X.index))
    X = X.copy()
    if s.isna().all():            # файла market_access нет — работаем без этого признака
        return X
    X["log_market_access"] = s.fillna(s.min())   # изолированные МО: минимальная доступность
    return X


# ------------------------------------------------------------------ сеть и типы
def build_graph(Z, k, mutual, metric):
    nn = NearestNeighbors(n_neighbors=k + 1, metric=metric).fit(Z)
    dist, idx = nn.kneighbors(Z)
    dist, idx = dist[:, 1:], idx[:, 1:]
    sigma = np.median(dist) + 1e-12
    nbrs = [set(r) for r in idx]
    G = nx.Graph()
    G.add_nodes_from(range(len(Z)))
    for i in range(len(Z)):
        for d, j in zip(dist[i], idx[i]):
            if (not mutual) or (i in nbrs[int(j)]):
                G.add_edge(i, int(j), weight=float(np.exp(-d ** 2 / (2 * sigma ** 2))))
    return G


def communities(G, resolution, seed):
    comms = nx.community.louvain_communities(G, weight="weight", resolution=resolution, seed=seed)
    labels = np.full(G.number_of_nodes(), -1)
    for c, nodes in enumerate(sorted(comms, key=len, reverse=True)):
        labels[list(nodes)] = c
    return labels


def merge_small(Z, labels, min_size):
    labels = labels.copy()
    sizes = pd.Series(labels).value_counts()
    big = sizes[sizes >= min_size].index.tolist()
    if len(big) >= 1:
        cent = np.vstack([Z[labels == c].mean(axis=0) for c in big])
        for c in sizes[sizes < min_size].index:
            for i in np.where(labels == c)[0]:
                labels[i] = big[int(np.argmin(((cent - Z[i]) ** 2).sum(axis=1)))]
    order = pd.Series(labels).value_counts().index.tolist()
    remap = {old: new for new, old in enumerate(order)}
    return np.array([remap[v] for v in labels])


def assign(Z, Zref, labels):
    cls = sorted(set(labels))
    cent = np.vstack([Zref[labels == c].mean(axis=0) for c in cls])
    d = ((Z[:, None, :] - cent[None, :, :]) ** 2).sum(axis=2)
    return np.array(cls)[d.argmin(axis=1)]


def modularity_of(G, labels):
    groups = [set(np.where(labels == c)[0].tolist()) for c in sorted(set(labels))]
    return nx.community.modularity(G, groups, weight="weight")


def typing(Z, cfg, k=None, resolution=None, seed=None):
    G = build_graph(Z, k or cfg["k"], cfg["mutual"], cfg["metric"])
    lab = communities(G, resolution or cfg["resolution"], seed if seed is not None else cfg["seed"])
    return G, merge_small(Z, lab, cfg["min_size"])


# ------------------------------------------------------------------ основной прогон
def run(cons, ma, out_dir, cfg=CFG):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    cats = find_categories(cons)
    w = full_panel(monthly_wide(cons, cats))
    n_mo = w.index.get_level_values("territory_id").nunique()
    print(f"МО в панели: {n_mo} из {cons['territory_id'].nunique()} (остальные с пропусками или нулями)")

    years = sorted(set(w.index.get_level_values("date").year))
    y0, y1 = years[0], years[-1]
    X0 = add_access(year_features(w, y0), ma)
    X1 = add_access(year_features(w, y1), ma)
    sc = StandardScaler().fit(X0)
    Z0, Z1 = sc.transform(X0), sc.transform(X1)
    cols = list(X0.columns)

    cfg = dict(cfg)
    print(f"\n== Выбор крупности типов (resolution), база {y0}, k={cfg['k']}")
    print("resolution  типов  модулярность  silhouette")
    best, best_sil = None, -1.0
    for res in (0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0):
        G, lab = typing(Z0, cfg, resolution=res)
        kk = len(set(lab))
        sil = silhouette_score(Z0, lab) if kk > 1 else float("nan")
        ok = cfg["k_types"][0] <= kk <= cfg["k_types"][1]
        print(f"{res:>10}  {kk:>5}  {modularity_of(G, lab):>12.3f}  {sil:>10.3f}{'' if ok else '   (вне диапазона типов)'}")
        if ok and sil > best_sil:
            best, best_sil = res, sil
    if cfg["resolution"] is None:
        cfg["resolution"] = best if best is not None else 1.0
    G, base = typing(Z0, cfg)
    K = len(set(base))
    print(f"\nВыбрано: resolution={cfg['resolution']}, типов: {K}, размеры: {np.bincount(base).tolist()}")

    # устойчивость и чувствительность
    labs = [typing(Z0, cfg, seed=s)[1] for s in range(5)]
    stab = np.mean([adjusted_rand_score(labs[0], l) for l in labs[1:]])
    print(f"\nУстойчивость к случайности алгоритма (средний ARI по 5 запускам): {stab:.3f}")
    print("Чувствительность к числу соседей k (ARI относительно выбранного k):")
    for kk in (5, 10, 20):
        _, lab_k = typing(Z0, cfg, k=kk)
        print(f"  k={kk:>2}: типов {len(set(lab_k))}, ARI = {adjusted_rand_score(base, lab_k):.3f}")
    km = KMeans(n_clusters=K, n_init=10, random_state=cfg["seed"]).fit_predict(Z0)
    print(f"Согласие с K-means (K={K}): ARI = {adjusted_rand_score(base, km):.3f}")

    # динамика: МО второго года -> типы первого года
    lab1 = assign(Z1, Z0, base)
    noise = float((assign(Z0, Z0, base) != base).mean())
    changed = float((lab1 != base).mean())
    print(f"\nДинамика {y0}->{y1}: сменили тип {changed:.1%} МО")
    print(f"Уровень шума (МО, не попавшие в свой же тип по ближайшему центру в {y0}): {noise:.1%}")
    print("Если смена типа не сильно выше шума, «динамику» трактовать нельзя.")
    trans = pd.crosstab(pd.Series(base, name=str(y0)), pd.Series(lab1, name=str(y1)), normalize="index")

    # профили типов в обычных единицах
    raw = month_features(w)
    raw["total_rub"] = w["total"]
    R0 = raw[raw.index.get_level_values("date").year == y0].groupby(level="territory_id").mean()
    types = pd.Series(base, index=X0.index, name="type")
    prof = R0.drop(columns="log_total").join(types).groupby("type").median()
    prof.insert(0, "n_MO", types.value_counts().sort_index())
    for c in prof.columns:
        if c.startswith("share_"):
            prof[c] = (prof[c] * 100).round(1)
    prof["total_rub"] = prof["total_rub"].round(0)
    zprof = pd.DataFrame(Z0, index=X0.index, columns=cols).join(types).groupby("type").mean()

    # сохранение
    res = pd.DataFrame(Z0, index=X0.index, columns=cols)
    res.to_csv(out / f"features_z_{y0}.csv")
    pd.DataFrame({"type": base, f"type_{y1}": lab1}, index=X0.index).to_csv(out / f"types_{y0}.csv")
    prof.to_csv(out / "type_profiles.csv")
    trans.round(3).to_csv(out / f"transitions_{y0}_{y1}.csv")
    print("\n== Профили типов (медианы, доли в %):")
    print(prof.to_string())

    # картинки
    P = PCA(n_components=2, random_state=0).fit_transform(Z0)
    fig, ax = plt.subplots(figsize=(7, 5))
    sc_ = ax.scatter(P[:, 0], P[:, 1], c=base, cmap="tab10", s=10)
    ax.set_title(f"Типы МО на плоскости двух главных компонент ({y0})")
    ax.legend(*sc_.legend_elements(), title="тип", loc="best")
    fig.tight_layout(); fig.savefig(out / "pca_types.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 0.6 * K + 2))
    im = ax.imshow(zprof.values, cmap="RdBu_r", vmin=-2, vmax=2, aspect="auto")
    ax.set_xticks(range(len(cols))); ax.set_xticklabels(cols, rotation=35, ha="right")
    ax.set_yticks(range(K)); ax.set_yticklabels([f"тип {i}" for i in zprof.index])
    for i in range(zprof.shape[0]):
        for j in range(zprof.shape[1]):
            ax.text(j, i, f"{zprof.values[i, j]:.1f}", ha="center", va="center", fontsize=8)
    ax.set_title("Профиль типов: отклонение от среднего (в стандартных отклонениях)")
    fig.colorbar(im); fig.tight_layout(); fig.savefig(out / "type_profiles.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5, 4.5))
    im = ax.imshow(trans.values, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(trans.shape[1])); ax.set_xticklabels(trans.columns)
    ax.set_yticks(range(trans.shape[0])); ax.set_yticklabels(trans.index)
    ax.set_xlabel(str(y1)); ax.set_ylabel(str(y0)); ax.set_title("Переходы между типами")
    for i in range(trans.shape[0]):
        for j in range(trans.shape[1]):
            ax.text(j, i, f"{trans.values[i, j]:.2f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im); fig.tight_layout(); fig.savefig(out / "transitions.png", dpi=150); plt.close(fig)
    print(f"\nГотово. Файлы и картинки: {out.resolve()}")
    return dict(base=base, stab=stab, noise=noise, changed=changed, X0=X0, Z0=Z0, K=K)


def fix_value_column(df):
    if "consumption" in df.columns:
        return df
    skip = {"territory_id", "date", "category"}
    num = [c for c in df.columns if c not in skip and pd.api.types.is_numeric_dtype(df[c])]
    if len(num) == 1:
        print(f"ВНИМАНИЕ: столбца 'consumption' нет, использую '{num[0]}'")
        return df.rename(columns={num[0]: "consumption"})
    raise SystemExit(f"Не нашёл столбец со значениями расходов. Столбцы: {list(df.columns)}")


def main():
    data = Path(sys.argv[1] if len(sys.argv) > 1 else "data")
    out = sys.argv[2] if len(sys.argv) > 2 else "outputs"
    cons = fix_value_column(pd.read_parquet(data / "consumption.parquet"))
    mf = data / "market_access.parquet"
    ma = pd.read_parquet(mf) if mf.exists() else pd.DataFrame({"territory_id": [], "market_access": []})
    print("Столбцы consumption:", list(cons.columns), "| market_access:", list(ma.columns))
    if "market_access" not in ma.columns and len(ma.columns) > 0:
        num = [c for c in ma.columns if c != "territory_id" and pd.api.types.is_numeric_dtype(ma[c])]
        if len(num) == 1:
            print(f"ВНИМАНИЕ: в market_access использую столбец '{num[0]}' как индекс доступности")
            ma = ma.rename(columns={num[0]: "market_access"})
        else:
            raise SystemExit(f"Не нашёл столбец индекса в market_access. Столбцы: {list(ma.columns)}")
    if ma.empty:
        print("(market_access.parquet не найден: признак доступности рынков пропускаю)")
    cons["territory_id"] = cons["territory_id"].astype(str)
    ma["territory_id"] = ma["territory_id"].astype(str)
    run(cons, ma, out)


if __name__ == "__main__":
    main()
